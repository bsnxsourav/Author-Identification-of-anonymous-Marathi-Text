#Get all tweets by username

import tweepy #https://github.com/tweepy/tweepy
import csv

consumer_key = "uAEagrG7DEn1pAZWTRIYWfGMs"
consumer_secret = "xZWD1J0QA28hoZEty5VvTdig1rfRS8Y2FT2KHFJ7hBBnIBFC5u"
access_key = "1250846281125126144-HKzxbpLG5gV4YmMP9CpB00Oz19Wb7J"
access_secret = "O8tRp7YyGQBpwT4HmNXAjJT0TGfSuyS0rK9yWnwWss4oR"
bearer_token = "AAAAAAAAAAAAAAAAAAAAAEv5WwEAAAAA0jxoDzDrvKyt6vcq3h6ijcfjerU%3DyN2dCkEGJdCcYq7jiP8xbjKYb7BIrM2rBQ3lzvrQRFv3N9omVU"
client = tweepy.Client(bearer_token=bearer_token, consumer_key=consumer_key,consumer_secret=consumer_secret, access_token=access_key, access_token_secret=access_secret)


#function to fetch user id from twitter handle.
def get_user_id(twitter_handle):
  response = client.get_user(username = twitter_handle)
  # print(f"{twitter_handle}: {response[0]['id']}")
  return response[0].id


#function writes all tweets to csv files
def writeTweets(twitter_handle, userTweets):
  with open(f'{twitter_handle}.csv', 'w') as csv_file:
    csv_writer = csv.writer(csv_file)
    csv_writer.writerow(['TEXT'])
    for tweet in userTweets:
      csv_writer.writerow([tweet.text])
 

def get_all_tweets(twitter_handle, id):
  response = client.get_users_tweets(id=id, max_results=100)
  userTweets = []
  while 'next_token' in response[3]:
    userTweets.extend(response[0])
    next_pagination_token = response[3]['next_token']
    response = client.get_users_tweets(id=id, max_results=100, pagination_token=next_pagination_token)
  else:
    userTweets.extend(response[0])
  writeTweets(twitter_handle, userTweets)
  print(f"Fetched {len(userTweets)} tweets in total form {twitter_handle}.")



namelist = ['PawarSpeaks'
,'swwapniljoshi'
,'SIDDHARTH23OCT'
,'meSonalee'
,'prasadoak17'
,'nanagpatekar'
,'dnyanada24'
,'rajivkhandekar'
,'RamdasAthawale'
,'sangrambhaiya'
,'kolhe_amol'
,'RRPSpeaks'
,'bb_thorat'
,'vijayshivtare']

namelis2t = ['vijayshivtare', 'nanagpatekar']

for name in namelis2t:
  twitter_handle = name
  id = get_user_id(twitter_handle)
  get_all_tweets(twitter_handle, id)
  